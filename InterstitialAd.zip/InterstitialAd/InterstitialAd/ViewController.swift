//
//  ViewController.swift
//  InterstitialAd
//
//  Created by MacBook Pro on 20/04/2024.
//

import UIKit
import GoogleMobileAds

class ViewController: UIViewController, GADFullScreenContentDelegate {

    private var interstitial: GADInterstitialAd?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    
        loadInterstitialAd()
        
    }
    
    @IBAction func showInterstitialBtn(_ sender: Any) {
        showInterstitialAd()
    }

    func loadInterstitialAd() {
        let adUnitID = "ca-app-pub-3940256099942544/4411468910"
        let request = GADRequest()
        
        GADInterstitialAd.load(withAdUnitID: adUnitID, request: request) { ad, error in
            if let error = error {
                print("Failed to load interstitial ad with error: \(error.localizedDescription)")
                return
            }
            
            self.interstitial = ad
            self.interstitial?.fullScreenContentDelegate = self
        }
    }
    
    func showInterstitialAd() {
        if let ad = interstitial {
            ad.present(fromRootViewController: self)
        } else {
            print("Ad wasn't ready")
        }
    }
    
    
}

